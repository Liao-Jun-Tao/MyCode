export interface TokenPayload {
    id?: number;
    name?: string;
    iat?: number;
}