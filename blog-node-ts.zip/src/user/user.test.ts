import app from '../app'
import request from "supertest"

const testUser = {
    name: 'testUser',
    password:'1'
}

describe('测试创建用户接口', () => {
    test('创建用户时必须提供用户名', async () => { 
        const response = await request(app)
            .post('/users')
            .send({ password: testUser.password })
        expect(response.status).toBe(400)
        expect(response.body).toEqual({ message:'请提供用户名'})
    })
})


