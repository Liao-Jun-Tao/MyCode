export class UserModel{
    id?:number;
    name?:string;
    password?:string;
}