<template>
  <div id="app">
    <div>
      fdfdfd111
    </div>
  </div>
</template>

<script>
// 切片大小
// chunk size


export default {
  name: "app"
};
</script>
