exports.getPosts = (ctx) => {
    ctx.response.body = '文章'
}