const config = {
    port: 3000,
    database: {
        DATABASE: 'nodesql',
        USERNAME: 'root',
        PASSWORD: '1234',
        HOST: 'localhost',
        PORT: 3306
    }
}
module.exports = config