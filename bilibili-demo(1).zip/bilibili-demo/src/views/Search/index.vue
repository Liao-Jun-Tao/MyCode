<template>
  <div>
    search
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>