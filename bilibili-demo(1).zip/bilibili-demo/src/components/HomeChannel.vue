<template>
  <div>
    HomeChannel
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>