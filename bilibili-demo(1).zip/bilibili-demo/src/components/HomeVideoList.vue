<template>
  <div>
    HomVideoList
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>