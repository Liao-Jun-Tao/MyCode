---
home: true
heroText: 三元同学的博客
tagline: 认真写点儿东西
# heroImage: /hero.png
# heroImageStyle: {
#   maxWidth: '600px',
#   width: '100%',
#   display: block,
#   margin: '9rem auto 2rem',
#   background: '#fff',
#   borderRadius: '1rem',
# }
bgImageStyle: { height: "450px" }
isShowTitleInHome: false
actionText: Guide
actionLink: /views/other/guide
---
