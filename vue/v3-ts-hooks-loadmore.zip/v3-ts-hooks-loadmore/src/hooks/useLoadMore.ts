/**
 * 加载更多的按钮
 * page 加载第几页
 * mvvm proxy list
 * 函数式编程 更加淋漓尽致
 */
import { computed, ref } from 'vue';
const useLoadMore = () => {
const loadMorePage = () => {
   
};

const isLastPage = computed(() => {

   });

const currentPage = ref(0);
	return {
		loadMorePage, // 函数
		isLastPage, // 最后一页
		currentPage // 页码
	};
};

export default useLoadMore;
