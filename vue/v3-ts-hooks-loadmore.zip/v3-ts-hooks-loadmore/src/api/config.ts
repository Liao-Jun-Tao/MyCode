import axios,    {AxiosRequestConfig } from 'axios';

export {
   axios,
}
export type {AxiosRequestConfig}
